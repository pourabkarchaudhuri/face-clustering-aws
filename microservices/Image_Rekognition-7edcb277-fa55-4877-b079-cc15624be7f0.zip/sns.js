var AWS = require('aws-sdk');
var sns = new AWS.SNS();

module.exports = {
    'SendMessage': function(callback){
      var params = {
          Message: process.env.TOPIC_MESSAGE, /* required */
          Subject: process.env.TOPIC_SUBJECT,
          TopicArn: process.env.TOPIC_ARN
        };
        sns.publish(params, function(err, data) {
          if(err){
              callback(err, null);
          } // an error occurred
          else{
              callback(null, data);
          }          // successful response
        });
    }
};