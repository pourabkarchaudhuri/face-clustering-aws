var AWS = require('aws-sdk');

var s3 = new AWS.S3({region: process.env.AWS_REGION});

module.exports = {
    'UploadImage': function (event, callback) {
        var payload = JSON.parse(event.body);
        var s3key = process.env.FOLDER_NAME + '/' + event.requestContext.requestId + '.jpg';
        let buf = new Buffer(payload.image.replace(/^data:image\/\w+;base64,/, ""), 'base64');
        var data = {
            Bucket: process.env.BUCKET_NAME,
            Key: s3key,
            Body: buf,
            ContentEncoding: 'base64',
            ContentType: 'image/jpeg'
        };
        s3.putObject(data, function (err, result) {
            if (err) {
                console.log("Error Uploading : " + err);
                callback(err, null);
            } else {
                console.log('Succesfully uploaded the image!' + JSON.stringify(result));
                callback(null, result);
            }
        });

    },

    'GetObjectsFromBucket': function (callback) {
        console.log("Get Object List Module");
        var params = {
            Bucket: process.env.BUCKET_NAME, /* required */
            FetchOwner: false,
            MaxKeys: 5000, //Play with this and Next Tokens
            Prefix: process.env.CLUSTER_FOLDER_NAME, //foldername inside bucket
            Delimiter: ".jpg"
        };

        s3.listObjectsV2(params, function (err, data) {
            if (err) {
                console.log(err, err.stack);
                callback(err, null);
            } // an error occurred
            else {
                console.log(data);
                callback(null, data);
            } // successful response
        });
    },
    
    'DeleteObjectFromBucket':function(bucketName,fileName,callback){
      
      var params = {
      Bucket: bucketName, 
      Key: fileName
      };
      
      s3.deleteObject(params, function(err, data) {
        if (err){
          
          console.log(err, err.stack); // an error occurred
          callback(err,null);  
        } 
        else{
          
          console.log(data);           // successful response
          callback(null,data);
        
          
        }
        
      });
      
    }




};