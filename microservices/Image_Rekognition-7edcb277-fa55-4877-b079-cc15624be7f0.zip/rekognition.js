var AWS = require('aws-sdk');

var rekognition = new AWS.Rekognition();

module.exports = {
    'SearchFaces': function(event, callback){
        var payload = JSON.parse(event.body);
        var s3key = process.env.FOLDER_NAME + '/' + event.requestContext.requestId + '.jpg';
        var params = {
          CollectionId: payload.gallery, 
          FaceMatchThreshold: 95, 
          Image: {
           S3Object: {
            Bucket: process.env.BUCKET_NAME, 
            Name: s3key
           }
          }, 
          MaxFaces: 5
         };
         rekognition.searchFacesByImage(params, function(err, result) {
           if (err){
               console.log("Error with Rekognition : " + err);
               callback(err, null);
           } // an error occurred
           
           else{
               console.log("Response from Rekognition : " + JSON.stringify(result));
               callback(null, result);
           }           // successful response
           
         });
    },
    'TrainFaces': function(event, callback){
       
        // console.log("Ingoing Payload : " + JSON.stringify(event));
        var s3key = event.path;
        var params = {
            CollectionId: event.gallery, /* required */
            Image: { /* required */
            // Bytes: new Buffer('...') || 'STRING_VALUE' /* Strings will be Base-64 encoded on your behalf */,
            S3Object: {
                Bucket: process.env.BUCKET_NAME,
                Name: s3key,
                // Version: 'STRING_VALUE'
            }
          },
          DetectionAttributes: ["DEFAULT"],
          ExternalImageId: event.empId
        };
        
        rekognition.indexFaces(params, function(err, data) {
            if (err){
                //  console.log(err, err.stack); 
                console.log("Indexing API Error : " + err);
                console.log("Data : " + JSON.stringify(event));
                 callback(err, null);
            }else{
                console.log("Data : " + JSON.stringify(event));
                console.log("Success to API");
                // console.log("Index API Response : " + JSON.stringify(data));
                callback(null, data);
            }
            
        });
    },
    
    'ListCollections': function(callback){
        var params = {
         };
         rekognition.listCollections(params, function(err, data) {
          if (err){
                //  console.log(err, err.stack); 
                console.log("ListCollections API Error : " + err);
                // console.log("Data : " + JSON.stringify(event));
                 callback(err, null);
            }else{
                // console.log("ListCollections : " + JSON.stringify(event));
                console.log("Success to API");
                // console.log("Index API Response : " + JSON.stringify(data));
                callback(null, data);
            }

         });
    },
    
    'DeleteCollections': function(event, callback){
        console.log("Obtained Id to delete : " + event.id);
        var params = {
          CollectionId: event.id
         };
         rekognition.deleteCollection(params, function(err, data) {
           if (err){
                //  console.log(err, err.stack); 
                console.log("DeleteCollections API Error : " + err);
                // console.log("Data : " + JSON.stringify(event));
                 callback(err, null);
            }else{
                // console.log("ListCollections : " + JSON.stringify(event));
                console.log("Success to API");
                // console.log("Index API Response : " + JSON.stringify(data));
                callback(null, data);
            }
         });
    },
    
    'CreateCollections': function(event, callback){
        
     var params = {
          CollectionId: event.id
         };
         rekognition.createCollection(params, function(err, data) {
           if (err){
                //  console.log(err, err.stack); 
                console.log("CreateCollections API Error : " + err);
                // console.log("Data : " + JSON.stringify(event));
                 callback(err, null);
            }else{
                // console.log("ListCollections : " + JSON.stringify(event));
                console.log("Success to API");
                // console.log("Index API Response : " + JSON.stringify(data));
                callback(null, data);
            }
         });
    },
    
    'CompareFaces': function(event, callback){
        
        
        var params = {
          CollectionId: process.env.GALLERY_NAME, 
          FaceMatchThreshold: 95, 
          Image: {
           S3Object: {
            Bucket: process.env.BUCKET_NAME, 
            Name: event
           }
          }, 
          MaxFaces: 5
         };
         rekognition.searchFacesByImage(params, function(err, result) {
           if (err){
               console.log("Error with Rekognition : " + err);
               callback(err, null);
           } // an error occurred
           
           else{
               console.log("Response from Rekognition : " + JSON.stringify(result));
               callback(null, result);
           }           // successful response
           
         });
    },
};
 