var s3Handlers = require('./s3');
var rekognitionHandlers = require('./rekognition');
var snsHandlers = require('./sns');

var deasync = require('deasync');


exports.handler = (event, context, callback) => {
       
    console.log(JSON.stringify(event));
    
    router(event,(err,response)=>{
        
        if(err == null){

            callback(null, {"statusCode":200,
              headers: {
                  "X-Requested-With": '*',
                "Access-Control-Allow-Headers": 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,x-requested-with',
                "Access-Control-Allow-Origin": '*',
                "Access-Control-Allow-Methods": 'POST,GET,OPTIONS',
                "Access-Control-Allow-Credentials" : true },
                "body":JSON.stringify(response)});
        }else{
            
            callback(err, null);
        }
        
    });

};

function router(event,callback){
    var imageCount=0;
    console.log("Inside Router");
    var payload = JSON.parse(event.body);
    if(event.path == "/query"){
      if(event.httpMethod == "POST"){
            console.log("/query POST");
            var s3key = process.env.FOLDER_NAME + '/' + event.requestContext.requestId + '.jpg';
            if(payload){
                console.log("Query exists");
                if(payload.gallery && payload.image){
                    //Call S3
                    s3Handlers.UploadImage(event, (err, result)=>{
                        if(err){
                            callback(null,responseFormator(event,500,err,true,"S3 Upload Error"));
                        }
                        else{
                            //Call Rekognition
                            console.log;
                            rekognitionHandlers.SearchFaces(event, (err, result)=>{
                                if(err){
                                    callback(null,responseFormator(event,500,err,true,"Rekognition Error",null));
                                }
                                else{
                                    
                                    
                                    
                                    
                                    callback(null,responseFormator(event,200,result,false,"Rekognition results",s3key));
                                }
                            });
                        }
                    });
                }
                else if(payload.gallery && !payload.image){
                    callback(null,responseFormator(event,400,{},true,"image in base64 is missing",null));
                }
                 else if(!payload.gallery && payload.image){
                    callback(null,responseFormator(event,400,{},true,"Rekognition gallery name is missing",null));
                }
            }
            else{
                callback(null,responseFormator(event,400,{},true,"there is no body or payload",null));
            }
      }
      
      else if(event.httpMethod == "GET"){
          console.log("/query GET");
          if(event.queryStringParameters){
            if(event.queryStringParameters.hasOwnProperty('path')){
                
               rekognitionHandlers.CompareFaces(event.queryStringParameters.path, (err, result)=>{
                                if(err){
                                    callback(null,responseFormator(event,500,err,true,"Rekognition Error",null));
                                }
                                else{
                                    
                                    
                                    if(typeof result.FaceMatches !== 'undefined' && result.FaceMatches.length > 0){
                                        
                                        let response = result.FaceMatches[0].Face.ExternalImageId;
                                        callback(null,responseFormator(event,200,response,false,"Rekognition results",event.queryStringParameters.path));
                                    }
                                    else{
                                        callback(null,responseFormator(event,200,null,false,"Rekognition results",event.queryStringParameters.path));
                                    }
                                    
                                }
                            });
            }   
            else{
                //no path
                callback(null,responseFormator(event,200,{},false,"Bad request. 'path' query param missing with s3key",null));
            }
          }
          else{
              //No query params
              callback(null,responseFormator(event,500,{},false,"Query params absent",null));
          }
          
          
      }

    }//end of query handler
    
    else if(event.path == "/train"){
      if(event.httpMethod == "POST"){
            console.log("/train POST");
            
            if(payload){
                console.log("Query exists");
                
                if(payload.gallery && payload.path && payload.empId){
                    //Call S3qQq
                    rekognitionHandlers.TrainFaces(payload, (err, result)=>{
                                if(err){
                                    callback(null,responseFormator(event,500,err,true,"Rekognition Error",null));
                                }
                                else{
                                    callback(null,responseFormator(event,200,result,false,"Rekognition results",payload.path));
                                }
                            });
                }
                

                
                else if(payload.gallery && !payload.path){
                    callback(null,responseFormator(event,400,{},true,"image in base64 is missing",null));
                }
                 else if(!payload.gallery && payload.path){
                    callback(null,responseFormator(event,400,{},true,"s3 path is missing",null));
                }
            }
            else{
                callback(null,responseFormator(event,400,{},true,"there is no body or payload",null));
            }
      }

    }//end of train handler
    
    else if(event.path == "/autotrain"){
        if(event.httpMethod == "POST"){
            console.log("/autotrain");
            
            if(payload){
                console.log("Query exists");
                
                if(payload.data){
                    
                    if(typeof payload.data !== 'undefined' && payload.data.length > 0){
                        var output = [];
                        
                        payload.data.forEach((element, i)=>{
                          var name = element.name;
                          
                          element.images.forEach((subElement,j)=>{
                            // console.log(subElement + " with " + name);
                            imageCount++;
                            let structure = {
                            
                            	path:subElement,
                            	empId:name,
                            	gallery: process.env.GALLERY_NAME
            
                            };
                            // console.log("Input Payload : " + JSON.stringify(payload));
                            
                            rekognitionHandlers.TrainFaces(structure, (err, result)=>{
                                if(err){
                                    console.log("Exit flow!");
                                    callback(null,responseFormator(event,500,err,true,"Rekognition Error",null));
                                }
                                else{
                                    console.log("SUCCESS");
                                    var personID, faceID;
                                    if(typeof result.FaceRecords !== 'undefined' && result.FaceRecords.length > 0){
                                        personID = result.FaceRecords[0].Face.ExternalImageId;
                                        faceID = result.FaceRecords[0].Face.FaceId;
                                    }
                                    else{
                                        personID = "FACE_NOT_DETECTED";
                                        faceID = "FACE_NOT_DETECTED";
                                        
                                    }
                                    
                                   
                                    
                                     var buildOutput = {
                                            file_reference: subElement,
                                            personId: personID,
                                            faceId: faceID,
                                            training_status:true
                                            
                                        };
                                    
                                    
                                    
                                    output.push(buildOutput);
                                  // callback(null,responseFormator(event,200,result,false,"Rekognition results",payload.path));
                                    console.log("CONDITION STATUS",output.length,payload.data.length,element.images.length);
                                    
                                    
                                    console.log("Image count :",imageCount);
                                    console.log("data is ready count is:",output.length);
                                    console.log("Image count is",imageCount);
                                    if(output.length==imageCount){
                                        console.log("Codition satisfied. Incoming Outputt : ",imageCount,output.length,JSON.stringify(output));
                                        callback(null,responseFormator(event,200,output,false,"Training results",null));
                                        
                                        //sending notification
                                        snsHandlers.SendMessage((err,data)=>{
                                            
                                            if(err){
                                                console.log("ERROR in sending notification",err)
                                            }else{
                                                console.log("Success, notification sent",data);
                                            }
                                            
                                        });
                                        
                                        //deleting Objectes
                                        
                                        payload.data.forEach((element)=>{
                                            element.images.forEach((subElement)=>{
                                        
                                                s3Handlers.DeleteObjectFromBucket(process.env.BUCKET_NAME,subElement,(err,data)=>{
                                                    
                                                    if(err){
                                                        console.log("ERROR in deleting object",err);
                                                    
                                                        
                                                    }else{
                                                        
                                                        console.log("DELETED",data);
                                                        
                                                    }
                                                    
                                                })
                                        
                                                
                                            })
                                        })
                                        
                                        
                                        
                                        
                                    }
                                }
                                
                            });
                            

                           
                          });
                          
                          
                        });
                        
                        
                          
                    }
                    
                    else{
                        callback(null,responseFormator(event,400,{},true,"Bad Request. 'data' dictionary is blank",null));
                    }
                   
                }
                
                else{
                    callback(null,responseFormator(event,400,{},true,"Bad Request. 'data' missing",null));
                }
                
            }
            else{
                callback(null,responseFormator(event,400,{},true,"Bad Request. there is no body or payload",null));
            }
        }
    }
    
    else if(event.path == "/collection"){
        if(event.httpMethod == "GET"){
            console.log("/GET collection. List collections");
            rekognitionHandlers.ListCollections((err, result)=>{
                if(err){
                    
                    // console.log("Exit flow!");
                    callback(null,responseFormator(event,500,err,true,"Rekognition Error",null));
                }
                else{
                    callback(null,responseFormator(event,200,result,false,"List of Collections",null));
                }
            });
            
        }
        
        else if(event.httpMethod == "POST"){
            console.log("/POST collection. Create collections");
            rekognitionHandlers.CreateCollections(payload, (err, result)=>{
                if(err){
                    
                    // console.log("Exit flow!");
                    callback(null,responseFormator(event,500,err,true,"Rekognition Error",null));
                }
                else{
                    callback(null,responseFormator(event,200,result,false,"Created Collection",null));
                }
            });
            
        }
        else if(event.httpMethod == "DELETE"){
            console.log("/DELETE collection. Delete collections");
            rekognitionHandlers.DeleteCollections(payload, (err, result)=>{
                if(err){
                    
                    // console.log("Exit flow!");
                    callback(null,responseFormator(event,500,err,true,"Rekognition Error",null));
                }
                else{
                    callback(null,responseFormator(event,200,result,false,"Deleted Collection",null));
                }
            });
            
        }
    }
    
    
}

function responseFormator(event, statusCode, payload, isError, message, key){
     
      
        
        var response={
            method:event.httpMethod,
            status:statusCode,
            file_reference:key,
            error:isError,
            message:message,
            results:payload
          };
        
      
  
    return response;
  }
  
